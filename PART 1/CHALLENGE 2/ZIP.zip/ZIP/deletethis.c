#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef char StrDate[11];   // for dates in string format "MM/DD/YYYY", ex. "10/24/2016"
typedef char Symbol[9];     // for stock names,  ex. "EEI", "SMPH","URC"

struct DailyData {
     StrDate date;
     float open, high, low, close;  // OHLC values
     float volume;
};

typedef struct DailyData DDType;

typedef char string[20];



int 
loadData (DDType list[], string stocks)
{
	FILE *fp;	
	
	StrDate date;
	float open, high, low, close;	//OHLC
	float volume;
	string dump;
	
	int i = 0;           // for array indexing
	
	fp = fopen(strcat("test",".txt"), "r");
	
	
	
	// read data from the text file
	if (fp != NULL) {
		
		fgets(dump, 20, fp);
//		fgets(dump, 20, fp);
		
		while ( fscanf(fp, "%s %f %f %f %f %f", date, &open, &high, &low, &close, &volume) == 6) {
			strcpy(list[i].date, date); 	//NOT FINAL FORMAT
			list[i].open = open;
			list[i].high = high;
			list[i].low = low;
			list[i].close = close;
			list[i].volume = volume;
//			printf ("test: this part is working \n");
			i++;
		}	
		
		fclose (fp);
	}
	else {
		fprintf(stderr, "ERROR: %s not found, program terminating...\n", stocks);
		exit(1);
	}
	
	return i+2;
	
}


const char *  fix_format(string dd, string mm, string yyyy){
	char date[4];
	static string format;
	date[0] = '0';
	
	if (strlen(dd)==1){
		date[1] = dd[0];
		strcpy(dd, date);
	}
	date[0] = '0';
	if (strlen(mm)==1){
		date[1] = mm[0];
		strcpy(mm, date);
	}
	if (strlen(yyyy)==2){
		date[0] = '2';
		date[1] = '0';
		date[2] = yyyy[0];
		date[3] = yyyy[1];
	}
	strcpy(format, dd);
	strcpy(format, "/");
	strcpy(format, mm);
	strcpy(format, "/");
	strcpy(format, yyyy);
	
	return format;
}

void
formatDate(DDType list[], int nEntries)
{
	int i, j, ctr=0;
	string dd, mm, yyyy;
	size_t len = strlen(dd);
	
	for (i = 0; i < nEntries; i++) {
		*dd = '\0';
		*mm = '\0';
		*yyyy = '\0';
		len = strlen(dd);
		ctr = 0;
		for (j=0; j<strlen(list[i].date); j++) {
			if (list[i].date[j] != '/') {				
				if(ctr == 0) {
					dd[len++] = list[i].date[j];
					dd[len] = '\0';
				}
				else if (ctr == 1) {
					mm[len++] = list[i].date[j];
					mm[len] = '\0';
				}
				else if (ctr == 2) {
					yyyy[len++] = list[i].date[j];
					yyyy[len] = '\0';
				}
			}
			else 
				ctr++;			
		}
		
		strcpy(list[i].date, fix_format(dd, mm, yyyy));
	}
	
	//save new date
}

int main(){
	
	int nEntries = 1;
	DDType 
	
	return 0;
}
